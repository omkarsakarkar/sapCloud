sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	var ODATA_BASE_URL = "/iotmms/v1/api/http/app.svc/";
	var SENSOR_TABLE = "NEO_BQD2EHZ7LM1JWQ0OUG2427NPT.T_IOT_41D07810BBE65B1315F5";

	function queryOData(table, queryOptions, cb) {
		// build oData URL
		var url = ODATA_BASE_URL + table + "?$format=json";
		for (var option in queryOptions)
			url += ("&" + option + "=" + queryOptions[option]);

		// execute HTTP GET		
		$.get(url, function(data) {
			cb(data.d.results);
		});
	}

	return Controller.extend("com.sap.dashboard.controller.Main", {
		formatMinutesAgo: function(val) {
			if (val === null)
				return "n/a";
			var currentTimestampInMillis = new Date().getTime();
			var pastTimestampInMillis = parseInt(val.substring(6, 19), 10);
			var differenceInSeconds = Math.floor((currentTimestampInMillis - pastTimestampInMillis) / 1000);
			return Math.floor(differenceInSeconds/60) + " minutes ago";
		},
		
		onInit: function() {
			var oModel = new JSONModel({
				temperature: {
					value: "n/a",
					timestamp: null
				},
				light: {
					value: "n/a",
					timestamp: null
				}
			});

			this.getView().setModel(oModel);

			function updateSensor(type) {
				queryOData(SENSOR_TABLE, {
						$top: 1,
						$orderby: "C_TIMESTAMP desc",
						$filter: "C_SENSORTYPE eq '" + type + "'"
					},
					function(results) {
						oModel.setProperty("/" + type, {
							value: results[0].C_SENSORVALUE,
							timestamp: results[0].C_TIMESTAMP
						});
						oModel.refresh(true);
					});
			}
			setInterval(function() {
				updateSensor("temperature");
				updateSensor("light");
			}, 1000);
		}
	});
});